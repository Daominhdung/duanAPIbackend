package com.example.backendwebtienganh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendwebtienganhApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendwebtienganhApplication.class, args);
	}

}

package com.example.backendwebtienganh.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // Trả về tên trang đăng nhập của bạn (ví dụ: "login")
    }
}

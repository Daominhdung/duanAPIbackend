package com.example.backendwebtienganh.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class member {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String email;

    private String password;
    private  int phone;

    // Constructor mặc định (cần thiết khi sử dụng JPA)
    public member() {
    }

    // Constructor có tham số (nếu muốn tạo đối tượng với giá trị ban đầu cho các thuộc tính)
    public member(String name, String email, String password, int phone) {
        this.name = name;
        this.email = email;
        this.password=password;
        this.phone=phone;
    }

    // Getter và setter cho thuộc tính "id"
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getter và setter cho thuộc tính "name"
    public String getName() {
        return name;
    }
    public String getPassword(){
        return password;
    }
    public int getPhone(){
        return phone;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public void setPhone(int phone){
        this.phone = phone;
    }
    public void setName(String name) {
        this.name = name;
    }

    // Getter và setter cho thuộc tính "email"
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Thêm các getter và setter cho các thuộc tính khác của thành viên (nếu có)

    @Override
    public String toString() {
        return "Member{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='"+password+'\''+
                ", phone='"+phone+'\''+
                // Thêm thông tin của các thuộc tính khác vào chuỗi trả về nếu có
                '}';
    }
}